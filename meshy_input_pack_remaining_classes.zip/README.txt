MESHY INPUT PACK — REMAINING CLASSES

Contains Swordfighter, Archer and Mage, male/female.
Use front + side + back first. Add three-quarter only if it improves consistency.
Target: stylized mobile RPG character, preserve exact class colors/silhouette, no weapon, neutral pose, game-ready GLB.
