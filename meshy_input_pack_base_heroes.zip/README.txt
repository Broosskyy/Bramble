MESHY INPUT PACK — BASE HEROES

Purpose:
Clean multi-view references for the shared-canon Base Hero Male/Female.

Recommended order in Meshy:
1. front
2. side
3. back
4. three_quarter (optional)

Target:
- stylized 3D mobile RPG character
- preserve exact clothing colors and proportions
- no weapon
- neutral standing pose
- clean topology suitable for rigging
- keep backpack/roll only if Meshy preserves it cleanly; otherwise remove during cleanup
